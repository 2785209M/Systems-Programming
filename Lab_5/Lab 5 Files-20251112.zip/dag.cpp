#include <cstdio>
#include <vector>
#include <memory>
#include <cstring>
#include <cstdlib>

struct node {
    // The node name 
    const char * value;
    // FIXME: Add a vector to hold node edges


    // Constructor
    node(const char * name) {
        //FIXME: Initialize node
    }
   
    // FIXME: Implement a member function add_edge_to
    //void add_edge_to(...) {}

};

int main() {
     std::?????_ptr<node> a = std::make_?????<node>("a");
     std::?????_ptr<node> b = std::make_?????<node>("b");
     std::?????_ptr<node> c = std::make_?????<node>("c");
     std::?????_ptr<node> d = std::make_?????<node>("d");
     std::?????_ptr<node> e = std::make_?????<node>("e");
     std::?????_ptr<node> f = std::make_?????<node>("f");

     a->add_edge_to(b);
     a->add_edge_to(d);
     b->add_edge_to(c);
     b->add_edge_to(d);
     c->add_edge_to(e);
     d->add_edge_to(f);
     e->add_edge_to(f);
}
