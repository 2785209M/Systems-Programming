#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct name {
    const char * first_name;
    const char * last_name;
};

typedef struct name name;

int main() {
    name names[4] = {
        {"Grace", "Hopper"},
        {"Dennis", "Ritchie"},
        {"Ken", "Thompson"},
        {"Bjarne", "Stroustrup"}
    };
    //sort array by first name using qsort
    //print array
    //sort array by last name using qsort
    //print array
}
