#include <cstdio>
#include <cstdlib>
#include <cstring>

struct buffer {
    int * ptr;
    //FIXME: ...maybe store some metadata

    //Constructor
    buffer(int initial_size) {
        //FIXME: Allocate enough memory for the given initial_size
    }


    //Destructor
    ~buffer() {
        //FIXME: Free memory
    }

    void add(int element) { 
        /* FIXME: 
            Check if there is enough room left in the buffer.
            If not, allocate new memory with enough space and
            copy all elements from the old memory over.
            Make sure not to leak memory!
        */
    }
};

//typedef struct buffer buffer;


int main() {
    buffer b(3);
    b.add(1);
    b.add(2);
    b.add(3);
    b.add(4);
}
