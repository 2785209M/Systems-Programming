#include <stdio.h>
#include <stdlib.h>
#define WORDS_MAX 50

void reverse_print(char **p, int n);

int main() {
    char *message[WORDS_MAX] =  {"I", "think", "we've", "got", "our", "roles", "reversed"};

    reverse_print(message,3);
    reverse_print(message, 16);
    reverse_print(message, 52);

}

void reverse_print(char **p, int n) {
    if (n > WORDS_MAX) {
        printf("\nReverse print called with n >> WORDS_MAX\n");
        return;
    }
    for (int i = n-1 ; i >= 0 ; i--) {
        if (p[i] != NULL)
            printf("%s ", p[i]);
    }
    printf("\n");
}

