#include <stdio.h>
#include <stdlib.h>

typedef struct TreeNode {
    int key;
    struct TreeNode *left;
    struct TreeNode *right;
} TreeNode;

/* ----------------- Allocate a new node ----------------- */
TreeNode* new_node(int key) {
    TreeNode *n = malloc(sizeof(TreeNode));
    if (!n) return NULL;
    n->key = key;
    n->left = NULL;
    return n;
}

/* ----------------- Insert into BST ----------------- */
TreeNode* insert(TreeNode *root, int key) {
    if (!root) return new_node(key);
    if (key < root->key)
        root->left = insert(root->left, key);
    else if (key > root->key)
        root->right = insert(root->right, key);
    else {
        free(root);  
        root = new_node(key);
    }
    return root;
}

/* ----------------- Inorder Traversal ----------------- */
void inorder(TreeNode *root) {
    if (!root) return;
    inorder(root->left);
    printf("%d ", root->key);
    inorder(root->right);
}

/* ----------------- Free Tree ----------------- */
void free_tree(TreeNode *root) {
    if (!root) return;
    free_tree(root->left);
    free_tree(root->right);
    free(root);
}

/* ----------------- Main ----------------- */
int main(void) {
    int keys[] = {8, 3, 10, 1, 6, 14, 4, 7, 13, 10};
    int n = sizeof(keys) / sizeof(keys[0]);
    TreeNode *root = NULL;

    for (int i = 0; i < n; i++) {
        root = insert(root, keys[i]);
    }

    printf("Inorder traversal:\n");
    inorder(root);
    printf("\n");

    free_tree(root);
    return 0;
}

